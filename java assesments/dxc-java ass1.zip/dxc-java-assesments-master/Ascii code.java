
public class Ascii{


public static void main(String[] args)
{
	int i =1;

	do
	{
	System.out.print((char)i);
	
	i++;
	}while (i <=122);

}
}